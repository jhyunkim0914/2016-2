#include "DiscountAlgorithm.h"

DiscountAlgorithm::DiscountAlgorithm()
{
}

DiscountAlgorithm::~DiscountAlgorithm()
{
}
