#include "Coffee.h"

Coffee::Coffee()
{
}

Coffee::~Coffee()
{
}
