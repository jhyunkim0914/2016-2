#include "App.h"

using namespace std;

int main()
{
	App app;
	app.run();

	return 0;
}